from django.apps import AppConfig


class DjangoDatatablesConfig(AppConfig):
    name = 'django_datatables'

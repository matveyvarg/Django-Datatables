DJANGO DATATABLES PACKAGE

Easy way ti implement datatables to your django application
